# -*- coding: utf-8 -*-
"""
Created on Thu Dec 10 14:11:51 2020

@author: Oyelade
"""

# Import libraries 
import matplotlib.pyplot as plt 
import numpy as np 
import seaborn as sns
sns.set() # Setting seaborn as default style even if use only matplotlib


# Creating dataset 
hybrids1=['CNN', 'CNN-GA', 'CNN-WOA', 'CNN-MVO', 'CNN-SBO', 'CNN-LCBO']
hybrids2=['C2-CNN', 'CNN-GA', 'CNN-WOA', 'CNN-MVO', 'CNN-SBO', 'CNN-LCBO']


data_1 = [[0.55, 0.58, 0.74, 0.78, 0.66]]  
data_2 = [[0.85, 0.87, 0.73, 0.67, 0.76]] 
data_3 = [[0.75, 0.77, 0.83, 0.81, 0.75]]
data_4 = [[0.85, 0.85, 0.85, 0.89, 0.84]] 
data_5 = [[0.80, 0.85, 0.85, 0.89, 0.80]] 
data_6 = [[0.83, 0.85, 0.86, 0.86, 0.86]] 
 
data1 = [data_1, data_2, data_3, data_4, data_5, data_6] 


data_1 = [[0.885, 0.885, 0.937]]  
data_2 = [[0.886, 0.875, 0.9375]] 
data_3 = [[0.875, 0.875, 0.9375]] 
data_4 = [[1.0, 1.0, 1.0]] 
data_5 = [[0.27, 0.45, 0.67]] 
data_6 = [[0.13, 0.25, 0.35]] 

data2 = [data_1, data_2, data_3, data_4, data_5, data_6]

colors = ['#73020C', '#426A8C']


colors_c1 = dict(color=colors[0])
colors_c2 = dict(color=colors[1])
box_colors = ['red', 'blue']    

plt.style.use('seaborn-white')
fig, axs = plt.subplots()
fig.subplots_adjust(hspace=1.9)
fig.tight_layout(pad=1.0)


bp=axs.boxplot(data1[0][0], positions=[1], labels=[hybrids1[0]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], color=box_colors[0])

bp=axs.boxplot(data1[1][0], positions=[2], labels=[hybrids1[1]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], color=box_colors[0])

bp=axs.boxplot(data1[2][0], positions=[3], labels=[hybrids1[2]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], color=box_colors[0])

bp=axs.boxplot(data1[3][0], positions=[4], labels=[hybrids1[3]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], color=box_colors[0])
bp=axs.boxplot(data1[4][0], positions=[5], labels=[hybrids1[4]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], color=box_colors[0])
bp=axs.boxplot(data1[5][0], positions=[6], labels=[hybrids1[5]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], color=box_colors[0])

axs.set(xlabel='', ylabel='C1-CNN and hybrid)')

'''
bp=axs[1].boxplot(data2[0][0], positions=[1], labels=[hybrids2[0]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], color=box_colors[1])
bp=axs[1].boxplot(data2[1][0], positions=[2], labels=[hybrids2[1]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], color=box_colors[1])
bp=axs[1].boxplot(data2[2][0], positions=[3], labels=[hybrids2[2]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], color=box_colors[1])
bp=axs[1].boxplot(data2[3][0], positions=[4], labels=[hybrids2[3]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], color=box_colors[1])
bp=axs[1].boxplot(data2[4][0], positions=[5], labels=[hybrids2[4]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], color=box_colors[1])
bp=axs[1].boxplot(data2[5][0], positions=[6], labels=[hybrids2[5]], boxprops=colors_c2, medianprops=colors_c2, 
        whiskerprops=colors_c2, capprops=colors_c2, flierprops=dict(markeredgecolor=colors[1]))
plt.setp(bp['boxes'], color=box_colors[1])
axs[1].set(xlabel='', ylabel='C2-CNN and hybrid')
plt.show() 
'''

'''
A figure with just one subplot

subplots() without arguments returns a Figure and a single Axes.

This is actually the simplest and recommended way of creating a single Figure and Axes.

fig, ax = plt.subplots()
ax.plot(x, y)
ax.set_title('A single plot')



Stacking subplots in one direction

The first two optional arguments of pyplot.subplots define the number of rows and columns of the subplot grid.

When stacking in one direction only, the returned axs is a 1D numpy array containing the list of created Axes.

fig, axs = plt.subplots(2)
fig.suptitle('Vertically stacked subplots')
axs[0].plot(x, y)
axs[1].plot(x, -y)



To obtain side-by-side subplots, pass parameters 1, 2 for one row and two columns.

fig, (ax1, ax2) = plt.subplots(1, 2)
fig.suptitle('Horizontally stacked subplots')
ax1.plot(x, y)
ax2.plot(x, -y)


You can use tuple-unpacking also in 2D to assign all subplots to dedicated variables:

fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2)
fig.suptitle('Sharing x per column, y per row')
ax1.plot(x, y)
ax2.plot(x, y**2, 'tab:orange')
ax3.plot(x, -y, 'tab:green')
ax4.plot(x, -y**2, 'tab:red')

for ax in fig.get_axes():
    ax.label_outer()


https://matplotlib.org/3.1.0/gallery/subplots_axes_and_figures/subplots_demo.html
'''