# -*- coding: utf-8 -*-
"""
Created on Fri Jul 10 16:02:04 2020

@author: Oyelade
"""

import matplotlib.pyplot as plt
plt.style.use('seaborn-whitegrid')
import numpy as np
from matplotlib.font_manager import FontProperties

N = 5
history=[{#'cnn': [0.55, 0.58, 0.74, 0.78, 0.66], #0.55, 0.58, 0.74, 0.78, 0.66 ~~ 644.72, 153.92, 362.74, 55.82, 20.18
         'cnnga': [0.85, 0.87, 0.73, 0.67, 0.76],  #0.85, 0.87, 0.73, 0.67, 0.76 ~~ 1247.6, 1180.7, 1047.0, 901.02, 841.39
        'cnnwoa': [0.75, 0.77, 0.83, 0.81, 0.75], #0.75, 0.77, 0.83, 0.81, 0.75 ~~~ 1249.7, 1127.3, 1014.9, 913.52, 819.94
        'cnnmvo': [0.84, 0.85, 0.85, 0.89, 0.84], #0.84, 0.85, 0.85, 0.89, 0.84 ~~ 1261.59, 1163.77, 1067.24, 1018.25, 892.44
        'cnnsbo': [0.80, 0.85, 0.85, 0.89, 0.80], #0.80, 0.85, 0.85, 0.89, 0.80 ~~~ 1253.14, 1140.89, 1036.5, 932.81, 852.62
        'cnnlcbo': [0.83, 0.85, 0.86, 0.86, 0.86] #0.83, 0.85, 0.86, 0.86, 0.86 ~~ 1266.86, 1180.28, 1090.75, 906.80, 816.07
        }, 
        {#'cnn': [4, 4, 4, 4, 4], 
         'cnnga': [23, 22, 22, 23, 23], 
        'cnnwoa': [23, 23, 23, 21, 21], 
        'cnnmvo': [23, 23, 23, 23, 22],
        'cnnsbo': [24, 23, 23, 23, 23],
        'cnnlcbo': [23, 22, 22, 22, 22]
        }]

hybrids=[#'CNN', 
         'CNN-GA', 'CNN-WOA', 'CNN-MVO', 'CNN-SBO', 'CNN-LCBO']
fontP = FontProperties()
fontP.set_size('xx-small')
fig, axs = plt.subplots()
#p1=axs.plot(np.arange(0, N),history[0]['cnn'])
p2=axs.plot(np.arange(0, N),history[0]['cnnga'])
p3=axs.plot(np.arange(0, N),history[0]['cnnwoa'])
p4=axs.plot(np.arange(0, N),history[0]['cnnmvo'])
p5=axs.plot(np.arange(0, N),history[0]['cnnsbo'])
p6=axs.plot(np.arange(0, N),history[0]['cnnlcbo'])
#axs.legend(hybrids, loc="upper left")
axs.legend(hybrids,bbox_to_anchor=(1.05, 1.05))
#axs.legend(handles=[p1,p2,p3,p4,p5,p6], title='title', bbox_to_anchor=(1.05, 1), loc='upper left', fontsize='xx-small')
axs.set(xlabel='Epoch', ylabel='Loss')

'''
axs[1].plot(np.arange(0, N),history[1]['cnn'])
axs[1].plot(np.arange(0, N),history[1]['cnnga'])
axs[1].plot(np.arange(0, N),history[1]['cnnwoa'])
axs[1].plot(np.arange(0, N),history[1]['cnnmvo'])
axs[1].plot(np.arange(0, N),history[1]['cnnsbo'])
axs[1].plot(np.arange(0, N),history[1]['cnnlcbo'])
axs[1].legend(hybrids, loc="upper left")
axs[1].set(xlabel='Epoch #', ylabel='Epoch Time')
'''