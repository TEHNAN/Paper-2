# -*- coding: utf-8 -*-
"""
Created on Fri Jun 18 17:40:11 2021
Ks = range(2, 10) # Amount of values to be tested for K
results = [] # List to hold on the metrics for each value of K
@author: Oyelade
"""

import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
import pylab as pl

DF = pd.read_csv('Mall_Customers.csv', encoding = 'utf-8')
DF_ARRAY = np.array(DF.iloc[:,2:5])          
DF_NORM  = preprocessing.normalize(DF_ARRAY) 

kmeans = KMeans(n_clusters = 4) # Creating our Model
kmeans.fit(DF_NORM)# Training our model

kmeans.labels_ # You can see the labels (clusters) assigned for each data point with the function labels_
DF['cluster'] = kmeans.labels_ # Assigning the labels to the initial dataset
PCA_ = PCA(n_components = 2).fit(DF_ARRAY) # Reducing data dimensions 
PCA_2 = PCA_.transform(DF_ARRAY) # Applying the PCA
pl.rcParams['figure.figsize'] = (8.0, 8.0) # Plot size

for i in range(0, PCA_2.shape[0]): 
    if kmeans.labels_[i] == 0:
        CLUSTER_01 = pl.scatter(PCA_2[i,0], PCA_2[i,1], c ='r', marker = 'o', s = 120)
        
    elif kmeans.labels_[i] == 1:
        CLUSTER_02 = pl.scatter(PCA_2[i,0], PCA_2[i,1], c ='g', marker = 'o', s = 120)

    elif kmeans.labels_[i] == 2:
        CLUSTER_03 = pl.scatter(PCA_2[i,0], PCA_2[i,1], c ='b', marker = 'o', s = 120)

    elif kmeans.labels_[i] == 3:
        CLUSTER_04 = pl.scatter(PCA_2[i,0], PCA_2[i,1], c ='y', marker = 'o', s = 120)
        
pl.legend([CLUSTER_01, CLUSTER_02, CLUSTER_03, CLUSTER_04],
          ['Cluster 01', 'Cluster 02', 'Cluster 03', 'Cluster 04'])  
pl.title('Mall Customers Categories')    
pl.show()


