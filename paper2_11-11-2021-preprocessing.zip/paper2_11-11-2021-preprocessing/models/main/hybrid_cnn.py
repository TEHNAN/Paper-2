#!/usr/bin/env python
# ------------------------------------------------------------------------------------------------------%
# Created by "Thieu Nguyen" at 21:19, 25/03/2020                                                        %
#                                                                                                       %
#       Email:      nguyenthieu2102@gmail.com                                                           %
#       Homepage:   https://www.researchgate.net/profile/Thieu_Nguyen6                                  %
#       Github:     https://github.com/thieunguyen5991                                                  %
#-------------------------------------------------------------------------------------------------------%

from models.root.hybrid.root_hybrid_deep_nets import RootHybridCnn, RootHybridCnn6, RootHybridCnnLenetHL
from mealpy.evolutionary_based import GA
from mealpy.swarm_based import WOA, SRSR, SSA, SSO
from mealpy.physics_based import MVO, EO
from mealpy.bio_based import SBO, BaseEBOA
from mealpy.human_based import LCBO
from mealpy.system_based import AEO

class EOSACnn(RootHybridCnn6):
    def __init__(self, root_base_paras=None, root_hybrid_paras=None, cnn_paras=None, eosa_paras=None):
        RootHybridCnn6.__init__(self, root_base_paras, root_hybrid_paras, cnn_paras)
        self.epoch = eosa_paras["epoch"]
        self.pop_size = eosa_paras["pop_size"]
        self.filename = "EOSA_CNN-" #+ root_hybrid_paras["paras_name"]
        self.model_rates=eosa_paras["model_rates"]

    def _training__(self):
        md = BaseEBOA.EBOA(self.model_rates, self._objective_function__, None, None, self.problem_size, 10, self.log, self.epoch, self.pop_size)
        self.solution, self.best_fit, self.loss_train = md._train__()

class WoaCnn(RootHybridCnn6):
    def __init__(self, root_base_paras=None, root_hybrid_paras=None, cnn_paras=None, woa_paras=None):
        RootHybridCnn6.__init__(self, root_base_paras, root_hybrid_paras, cnn_paras)
        self.epoch = woa_paras["epoch"]
        self.pop_size = woa_paras["pop_size"]
        self.filename = "WOA_CNN-" #+ root_hybrid_paras["paras_name"]

    def _training__(self):
        md = WOA.BaseWOA(self._objective_function__, None, None, self.problem_size, 10, self.log, self.epoch, self.pop_size)
        self.solution, self.best_fit, self.loss_train = md.train()

class GaCnn(RootHybridCnn6):
    def __init__(self, root_base_paras=None, root_hybrid_paras=None, cnn_paras=None, ga_paras=None):
        RootHybridCnn6.__init__(self, root_base_paras, root_hybrid_paras, cnn_paras)
        self.epoch = ga_paras["epoch"]
        self.pop_size = ga_paras["pop_size"]
        self.pc = ga_paras["pc"]
        self.pm = ga_paras["pm"]
        self.filename = "GA_CNN-" #+ root_hybrid_paras["paras_name"]

    def _training__(self):
        ga = GA.BaseGA(self._objective_function__, None, None, self.problem_size, 10, self.log, self.epoch, self.pop_size, self.pc, self.pm)
        self.solution, self.best_fit, self.loss_train = ga.train()

class LcboCnn(RootHybridCnn6):
    def __init__(self, root_base_paras=None, root_hybrid_paras=None, cnn_paras=None, lcbo_paras=None):
        RootHybridCnn6.__init__(self, root_base_paras, root_hybrid_paras, cnn_paras)
        self.epoch = lcbo_paras["epoch"]
        self.pop_size = lcbo_paras["pop_size"]
        self.filename = "LCBO_CNN-" #+ root_hybrid_paras["paras_name"]

    def _training__(self):
        md = LCBO.ModifiedLCO(self._objective_function__, None, None, self.problem_size, 10, self.log, self.epoch, self.pop_size)
        self.solution, self.best_fit, self.loss_train = md.train()


class SsoCnn(RootHybridCnn6):
    def __init__(self, root_base_paras=None, root_hybrid_paras=None, cnn_paras=None, sso_paras=None):
        RootHybridCnn6.__init__(self, root_base_paras, root_hybrid_paras, cnn_paras)
        self.epoch = sso_paras["epoch"]
        self.pop_size = sso_paras["pop_size"]
        self.filename = "SOO_CNN-" #+ root_hybrid_paras["paras_name"]

    def _training__(self):
        md = SSO.BaseSSO(self._objective_function__, None, None, self.problem_size, 10, self.log, self.epoch, self.pop_size)
        self.solution, self.best_fit, self.loss_train = md.train()
        
        
class SboCnn(RootHybridCnn6):
    def __init__(self, root_base_paras=None, root_hybrid_paras=None, cnn_paras=None, sbo_paras=None):
        RootHybridCnn6.__init__(self, root_base_paras, root_hybrid_paras, cnn_paras)
        self.epoch = sbo_paras["epoch"]
        self.pop_size = sbo_paras["pop_size"]
        self.alpha = sbo_paras["alpha"]
        self.pm = sbo_paras["pm"]
        self.z = sbo_paras["z"]
        self.filename = "SBO_CNN-" #+ root_hybrid_paras["paras_name"]

    def _training__(self):
        md = SBO.BaseSBO(self._objective_function__, None, None, self.problem_size, 10, self.log, self.epoch, self.pop_size, self.alpha, self.pm, self.z)
        self.solution, self.best_fit, self.loss_train = md.train()


class SsaCnn(RootHybridCnn6):
    def __init__(self, root_base_paras=None, root_hybrid_paras=None, cnn_paras=None, ssa_paras=None):
        RootHybridCnn6.__init__(self, root_base_paras, root_hybrid_paras, cnn_paras)
        self.epoch = ssa_paras["epoch"]
        self.pop_size = ssa_paras["pop_size"]
        self.r_a = ssa_paras["r_a"] #=1
        self.p_c = ssa_paras["p_c"] #=0.7
        self.p_m = ssa_paras["p_m"] #=0.1        
        self.filename = "SSA_CNN-"# + root_hybrid_paras["paras_name"]

    def _training__(self):
        md = SSA.OriginalSSA(self._objective_function__, None, None, self.problem_size, 10, self.log, self.epoch, 
                       self.pop_size, self.r_a, self.p_c, self.p_m)
        self.solution, self.best_fit, self.loss_train = md.train()
        
        
class SrsrCnn(RootHybridCnn6):
    def __init__(self, root_base_paras=None, root_hybrid_paras=None, cnn_paras=None, srsr_paras=None):
        RootHybridCnn6.__init__(self, root_base_paras, root_hybrid_paras, cnn_paras)
        self.epoch = srsr_paras["epoch"]
        self.pop_size = srsr_paras["pop_size"]
        self.filename = "SRSR_CNN-" #+ root_hybrid_paras["paras_name"]

    def _training__(self):
        md = SRSR.BaseSRSR(self._objective_function__, None, None, self.problem_size, 10, self.log, self.epoch, self.pop_size)
        self.solution, self.best_fit, self.loss_train = md.train()


class AeoCnn(RootHybridCnn6):
    def __init__(self, root_base_paras=None, root_hybrid_paras=None, cnn_paras=None, aeo_paras=None):
        RootHybridCnn6.__init__(self, root_base_paras, root_hybrid_paras, cnn_paras)
        self.epoch = aeo_paras["epoch"]
        self.pop_size = aeo_paras["pop_size"]
        self.filename = "AEO_CNN-" #+ root_hybrid_paras["paras_name"]

    def _training__(self):
        md = AEO.AdaptiveAEO(self._objective_function__, None, None, self.problem_size, 10, self.log, self.epoch, self.pop_size)
        self.solution, self.best_fit, self.loss_train = md.train()


class MvoCnn(RootHybridCnn6):
    def __init__(self, root_base_paras=None, root_hybrid_paras=None, cnn_paras=None, mvo_paras=None):
        RootHybridCnn6.__init__(self, root_base_paras, root_hybrid_paras, cnn_paras)
        self.epoch = mvo_paras["epoch"]
        self.pop_size = mvo_paras["pop_size"]
        self.wep_minmax = mvo_paras["wep_minmax"]
        self.filename = "MVO_CNN-" #+ root_hybrid_paras["paras_name"]

    def _training__(self):
        md = MVO.BaseMVO(self._objective_function__, None, None, self.problem_size, 10, self.log, self.epoch, self.pop_size, self.wep_minmax)
        self.solution, self.best_fit, self.loss_train = md.train()


class EoCnn(RootHybridCnn6):
    def __init__(self, root_base_paras=None, root_hybrid_paras=None, cnn_paras=None, eo_paras=None):
        RootHybridCnn6.__init__(self, root_base_paras, root_hybrid_paras, cnn_paras)
        self.epoch = eo_paras["epoch"]
        self.pop_size = eo_paras["pop_size"]
        self.filename = "EO_CNN-"# + root_hybrid_paras["paras_name"]

    def _training__(self):
        md = EO.LevyEO(self._objective_function__, None, None, self.problem_size, 10, self.log, self.epoch, self.pop_size)
        self.solution, self.best_fit, self.loss_train = md.train()

