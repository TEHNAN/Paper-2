#!/usr/bin/env python
# ------------------------------------------------------------------------------------------------------%
# Created by "Thieu Nguyen" at 20:59, 25/03/2020                                                        %
#                                                                                                       %
#       Email:      nguyenthieu2102@gmail.com                                                           %
#       Homepage:   https://www.researchgate.net/profile/Thieu_Nguyen6                                  %
#       Github:     https://github.com/thieunguyen5991                                                  %
#-------------------------------------------------------------------------------------------------------%

from sklearn.metrics import mean_absolute_error, mean_squared_error
import tensorflow as tf
#from keras.layers import Dense, LSTM, Dropout, GRU, Flatten
#from keras.layers.convolutional import Conv1D, MaxPooling1D
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import InputLayer
from pool_helper import PoolHelper
from tensorflow.python.keras.regularizers import l2
from lrn import LRN
from keras import backend
#from tensorflow.python.keras.layers import Input, Dense, Conv2D, MaxPooling2D, AveragePooling2D, ZeroPadding2D, Dropout, Flatten, Concatenate, Reshape, Activation
from keras.layers import LSTM, GRU, Input
from tensorflow.keras.layers import Conv2D, Dense, Dropout, Flatten, MaxPooling2D, AveragePooling2D, ZeroPadding2D, Concatenate, Reshape, Activation
from keras.utils.np_utils import to_categorical
from time import time
from numpy import reshape
from numpy.random import rand
from models.root.root_base import RootBase
import utils.MathUtil as my_math
import numpy as np
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.metrics import cohen_kappa_score
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt 
from tensorflow.keras.layers import BatchNormalization



class RootHybridDeepNets(RootBase):
    """
        This is root of all hybrid recurrent neural network (meta-heuristics + RNNs)
    """

    def __init__(self, root_base_paras=None, root_hybrid_paras=None):
        RootBase.__init__(self, root_base_paras)
        self.domain_range = root_hybrid_paras["domain_range"]
        self.activations = root_hybrid_paras["activations"]
        self.dropouts = root_hybrid_paras["dropouts"]
        if root_hybrid_paras["hidden_sizes"][-1]:
            self.hidden_sizes = root_hybrid_paras["hidden_sizes"][0]
        else:
            self.hidden_sizes = 2 * root_base_paras["sliding"] * root_base_paras["feature_size"] + 1
        ## New discovery
        self._activation1__ = getattr(my_math, self.activations[0])
        self._activation2__ = getattr(my_math, self.activations[1])

        self.model_rnn = None
        self.problem_size = None
        self.epoch = None

    def _building_architecture__(self):
        pass

    def _setting_paras__(self):
        weights = [rand(*w.shape) for w in self.model_rnn.get_weights()]
        problem_size = 0
        for wei in weights:
            # print(wei.shape)
            # print(len(wei.reshape(-1)))
            problem_size += len(wei.reshape(-1))
        self.problem_size = problem_size
        # self.y_train = self.y_train.reshape(-1, 1)
        # self.input_size, self.output_size = self.X_train.shape[1], self.y_train.shape[1]
    def _forecasting__(self):
        self.model_rnn.set_weights(self.model)
        y_pred = self.model_rnn.predict(self.X_test)
        y_pred_unscaled = self.time_series._inverse_scaling__(y_pred, scale_type=self.scaling)
        y_true_unscaled = self.time_series._inverse_scaling__(self.y_test, scale_type=self.scaling)
        return y_true_unscaled, y_pred_unscaled, self.y_test, y_pred
    
    
    def _running__(self):
        self.time_system = time()
        self._processing__()
        self._building_architecture__()
        self._setting_paras__()
        self.time_total_train = time()
        self._training__()
        self._get_model__(self.solution)
        self.time_total_train = round(time() - self.time_total_train, 4)
        self.time_epoch = round(self.time_total_train / self.epoch, 4)
        self.time_predict = time()
        y_true_unscaled, y_pred_unscaled, y_true_scaled, y_pred_scaled = self._forecasting__()
        self.time_predict = round(time() - self.time_predict, 8) 
        self.time_system = round(time() - self.time_system, 4)
        self._save_results__(y_true_unscaled, y_pred_unscaled, y_true_scaled, y_pred_scaled, self.loss_train, [], self.epoch_times, self.n_runs)
        self._fitmodel__()
        

    def _fitmodel__(self):
        self.model_rnn.set_weights(self.model)
        self.model_rnn.compile(loss="categorical_crossentropy", 
                               optimizer=tf.keras.optimizers.Adam(learning_rate=0.001, beta_1=0.9, beta_2=0.999, epsilon=1e-8), 
                               metrics=['accuracy'])
        ml = self.model_rnn.fit(self.X_train, self.y_train, 
                                validation_data=(self.X_test, self.y_test),
                                validation_steps=self.X_test.shape[0]//32,
                                epochs=10, batch_size=32, verbose=1)
        print(ml)
        y_pred = self.model_rnn.predict(self.X_test)
    
        yhat_classes_2 = y_pred.argmax(axis=1) 
        classes_2=self.y_test.argmax(axis=1)  #np.argmax(y_true, axis=1)
        #print(y_pred)
        #print(y_pred.shape)
        #print(classes_2)
        print(str(len(classes_2))+'Confusion Matrix1'+str(yhat_classes_2.shape))
        print(confusion_matrix(classes_2, yhat_classes_2))
        cm = confusion_matrix(classes_2, yhat_classes_2)
        plt.imshow(cm, cmap=plt.cm.Blues)
        plt.xlabel("Predicted labels")
        plt.ylabel("True labels")
        plt.xticks([], [])
        plt.yticks([], [])
        plt.title('Confusion matrix ')
        plt.colorbar()
        plt.show()
        
        print('Classification Report')
        print(classification_report(classes_2, yhat_classes_2))
        # accuracy: (tp + tn) / (p + n)
        accuracy = accuracy_score(classes_2, yhat_classes_2)
        print('Accuracy: %f' % accuracy)
        
        # precision tp / (tp + fp)
        precision = precision_score(classes_2, yhat_classes_2, average='micro')
        print('Precision micro: %f' % precision)
        precision2 = precision_score(classes_2, yhat_classes_2, average='macro')
        print('Precision macro: %f' % precision2)
        precision3 = precision_score(classes_2, yhat_classes_2, average='weighted')
        print('Precision weighted: %f' % precision3)
        precision4 = precision_score(classes_2, yhat_classes_2, average=None)
        print('Precision None: ' + str(precision4))
        
        # recall: tp / (tp + fn)
        recall = recall_score(classes_2, yhat_classes_2, average='micro')
        print('Recall micro: %f' % recall)
        recall2 = recall_score(classes_2, yhat_classes_2, average='macro')
        print('Recall macro: %f' % recall2)
        recall3 = recall_score(classes_2, yhat_classes_2, average='weighted')
        print('Recall weighted: %f' % recall3)
        recall4 = recall_score(classes_2, yhat_classes_2, average=None)
        print('Recall None: ' + str(recall4))
        
        # f1: 2 tp / (2 tp + fp + fn)
        f1 = f1_score(classes_2, yhat_classes_2, average='micro')
        print('F1 score micro: %f' % f1)
        f1_2 = f1_score(classes_2, yhat_classes_2, average='macro')
        print('F1 score macro: %f' % f1_2)
        f1_3 = f1_score(classes_2, yhat_classes_2, average='weighted')
        print('F1 score weighted: %f' % f1_3)
        f1_4 = f1_score(classes_2, yhat_classes_2, average=None)
        print('F1 score None: ' + str(f1_4))
        
        # kappa
        kappa = cohen_kappa_score(classes_2, yhat_classes_2)
        print('Cohens kappa: %f' % kappa)
        
        CM = confusion_matrix(classes_2, yhat_classes_2)
        TN = CM[0][0]
        FN = CM[1][0]
        TP = CM[1][1]
        FP = CM[0][1]
        specificity = TN / (TN+FP)
        sensitivity  = TP / (TP+FN)
        print('specificity3: %f' % specificity)
        print('sensitivity3: %f' % sensitivity)
        self._save_train_results__(accuracy, [precision, precision2, precision3, precision4],[recall, recall2, recall3, recall4],
                                   [f1, f1_2, f1_3, f1_4], kappa, sensitivity, specificity)
        
        self.loss_train = ml.history["loss"]
        self.accuracy_train = ml.history["accuracy"]
        return self.accuracy_train

    ## Helper functions
    def _get_model__(self, individual=None):
        weights = [rand(*w.shape) for w in self.model_rnn.get_weights()]
        ws = []
        cur_point = 0
        for wei in weights:
            ws.append(reshape(individual[cur_point:cur_point + len(wei.reshape(-1))], wei.shape))
            cur_point += len(wei.reshape(-1))
        self.model = ws

    def _get_average_error__(self, individual=None, X_data=None, y_data=None):
        t1 = time()
        weights = [rand(*w.shape) for w in self.model_rnn.get_weights()]
        ws = []
        cur_point = 0
        for wei in weights:
            ws.append(reshape(individual[cur_point:cur_point + len(wei.reshape(-1))], wei.shape))
            cur_point += len(wei.reshape(-1))

        self.model_rnn.set_weights(ws)
        y_pred = self.model_rnn.predict(X_data)
        # print("GAE time: {}".format(time() - t1))

        # return [mean_squared_error(y_pred, y_data), mean_absolute_error(y_pred, y_data)]
        return tf.keras.losses.categorical_crossentropy(y_pred, y_data)

    def _objective_function__(self, solution=None):
        weights = [rand(*w.shape) for w in self.model_rnn.get_weights()]
        ws = []
        cur_point = 0
        for wei in weights:
            ws.append(reshape(solution[cur_point:cur_point + len(wei.reshape(-1))], wei.shape))
            cur_point += len(wei.reshape(-1))

        self.model_rnn.set_weights(ws)
        y_pred = self.model_rnn.predict(self.X_train)
        #print(self.y_train.shape)
        #y_train = np.squeeze(to_categorical(self.y_train), axis=2)
        return tf.keras.losses.categorical_crossentropy(y_pred, self.y_train)

class RootHybridCnn6(RootHybridDeepNets):
    
    def __init__(self, root_base_paras=None, root_hybrid_paras=None, cnn_paras=None):
        RootHybridDeepNets.__init__(self, root_base_paras, root_hybrid_paras)
        self.filters_size = cnn_paras["filters_size"]
        self.kernel_size = cnn_paras["kernel_size"]
        self.pool_size = cnn_paras["pool_size"]
        
    def _building_architecture__(self):
        #  The CNN 1-HL architecture
        self.model_rnn = tf.keras.Sequential()
        num_classes=2
        
        self.model_rnn.add(InputLayer(input_shape=( 150, 150 ,1), name='input'))
        self.model_rnn.add(Conv2D(filters=32, kernel_size=(3,3), strides=(1,1), padding='same',
                              activation=self.activations[0],  kernel_regularizer=l2(0.0002)))
        self.model_rnn.add(Conv2D(filters=32, kernel_size=(3,3), strides=(1,1), padding='same', 
                              activation=self.activations[1], kernel_regularizer=l2(0.0002)))
        self.model_rnn.add(ZeroPadding2D(padding=(1, 1))) 
        self.model_rnn.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding='same', name='pool1/2x2_s1'))
        
         
        self.model_rnn.add(Conv2D(filters=64, kernel_size=(3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], kernel_regularizer=l2(0.0002)))
        self.model_rnn.add(Conv2D(filters=64, kernel_size=(3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1],  kernel_regularizer=l2(0.0002)))
        self.model_rnn.add(ZeroPadding2D(padding=(1, 1)))
        self.model_rnn.add(MaxPooling2D(pool_size=(3, 3), strides=(2, 2), padding='same', name='pool2/3x3_s2'))
         
        self.model_rnn.add(Conv2D(128, kernel_size=(3,3), strides=(1,1), padding='same', 
                              activation=self.activations[1], kernel_regularizer=l2(0.0002)))
        self.model_rnn.add(Conv2D(128, kernel_size=(3,3), strides=(1), padding='same', 
                              activation=self.activations[1],  kernel_regularizer=l2(0.0002)))
        self.model_rnn.add(ZeroPadding2D(padding=(1, 1)))
        self.model_rnn.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding='same', name='pool3/2x2_s1'))
         
        self.model_rnn.add(Conv2D(256, kernel_size=(3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], kernel_regularizer=l2(0.0002)))
        self.model_rnn.add(Conv2D(256, kernel_size=(3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], kernel_regularizer=l2(0.0002)))
         
        self.model_rnn.add(ZeroPadding2D(padding=(1, 1)))
        self.model_rnn.add(MaxPooling2D(pool_size=(3, 3), strides=(2, 2), padding='same', name='pool4/3x3_s2'))
         
        '''
        self.model_rnn.add(Conv2D(512, kernel_size=(3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1],  kernel_regularizer=l2(0.0002)))
        self.model_rnn.add(Conv2D(512, kernel_size=(3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1],  kernel_regularizer=l2(0.0002)))
        self.model_rnn.add(ZeroPadding2D(padding=(1, 1)))
        self.model_rnn.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding='same', name='pool5/2x2_s1'))  
         
         
        self.model_rnn.add(Conv2D(1024, kernel_size=(3,3), strides=(1,1), padding='same', 
                              activation=self.activations[1], kernel_regularizer=l2(0.0002)))
        self.model_rnn.add(Conv2D(1024, kernel_size=(3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1],  kernel_regularizer=l2(0.0002)))
        self.model_rnn.add(ZeroPadding2D(padding=(1, 1)))
        self.model_rnn.add(MaxPooling2D(pool_size=(3, 3), strides=(2, 2), padding='same', name='pool6/3x3_s2'))
        self.model_rnn.add(AveragePooling2D(pool_size=(2, 2), strides=(1, 1), name='pool7/2x2_s1'))  
        ''' 
        self.model_rnn.add(Flatten())
        self.model_rnn.add(Dropout(rate=0.5))
        self.model_rnn.add(Dense(num_classes, name='loss3/classifier', kernel_regularizer=l2(0.0002)))
        self.model_rnn.add(Activation('softmax', name='prob'))
        
class RootHybridCnnLenetHL(RootHybridDeepNets):
    """
        CNN with Lenet Hidden Layer
    """
    def __init__(self, root_base_paras=None, root_hybrid_paras=None, cnn_paras=None):
        RootHybridDeepNets.__init__(self, root_base_paras, root_hybrid_paras)
        self.filters_size = cnn_paras["filters_size"]
        self.kernel_size = cnn_paras["kernel_size"]
        self.pool_size = cnn_paras["pool_size"]

    def _building_architecture__(self):
        #  The CNN Lenet-HL architecture
        self.model = Sequential()
        num_classes=2
        
        self.model.add(Conv2D(filters=32, kernel_size=(3,3), strides=(1,1), padding='same',
                              #self.X_train.shape[1], self.X_train.shape[1]
                              activation=self.activations[0], input_shape=(  114, 114,1), 
                              name='conv1_1/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(filters=32, kernel_size=(3,3), strides=(1,1), padding='same', 
                              activation=self.activations[1], 
                              name='conv1_2/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(filters=128, kernel_size=(5,5), strides=(1,1), padding='same', 
                              activation=self.activations[1], 
                              name='conv1_3/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1))) 
        self.model.add(MaxPooling2D(pool_size=(2,2), strides=(1, 1), padding='same', name='pool1/2x2_s1'))
        
        self.model.add(Conv2D(filters=64, kernel_size=(3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv2_1/3x3_reduce', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(filters=64, kernel_size=(3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv2_2/3x3', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(filters=256, kernel_size=(5,5), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv2_3/3x3', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1)))
        self.model.add(MaxPooling2D(pool_size=(3, 3), strides=(2, 2), padding='same', name='pool2/3x3_s2'))
        
        self.model.add(Conv2D(128, kernel_size=(3,3), strides=(1,1), padding='same', 
                              activation=self.activations[1],  
                              name='conv3_1/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(128, kernel_size=(3,3), strides=(1), padding='same', 
                              activation=self.activations[1],  
                              name='conv3_2/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(256, kernel_size=(5,5), strides=(1), padding='same', 
                              activation=self.activations[1],  
                              name='conv3_3/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1)))
        self.model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding='same', name='pool3/2x2_s1'))
        
        self.model.add(Conv2D(256, kernel_size=(3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv4_1/3x3_reduce', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(256, kernel_size=(3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv4_2/3x3', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(1024, kernel_size=(5,5), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv4_3/3x3', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1)))
        self.model.add(MaxPooling2D(pool_size=(3, 3), strides=(2, 2), padding='same', name='pool4/3x3_s2'))
        
        self.model.add(Conv2D(512, kernel_size=(3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv5_1/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(512, kernel_size=(3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv5_2/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(2048, kernel_size=(5,5), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv5_3/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1)))
        self.model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding='same', name='pool5/2x2_s1'))
        
        self.model.add(Conv2D(1024, kernel_size=(3,3), strides=(1,1), padding='same', 
                              activation=self.activations[1], 
                              name='conv6_1/3x3_reduce', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(1024, kernel_size=(3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv6_2/3x3', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(1024, kernel_size=(5,5), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv6_3/3x3', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1)))
        self.model.add(MaxPooling2D(pool_size=(3, 3), strides=(2, 2), padding='same', name='pool6/3x3_s2'))
        self.model.add(AveragePooling2D(pool_size=(2, 2), strides=(1, 1), name='pool7/2x2_s1'))
        
        self.model.add(Flatten())
        self.model.add(Dropout(rate=0.5))
        self.model.add(Dense(num_classes, name='loss3/classifier', kernel_regularizer=l2(0.0002)))
        #self.model.add(Activation('softmax', name='prob'))
        
        
        
class RootHybridCnn(RootHybridDeepNets):

    def __init__(self, root_base_paras=None, root_hybrid_paras=None, cnn_paras=None):
        RootHybridDeepNets.__init__(self, root_base_paras, root_hybrid_paras)
        self.filters_size = cnn_paras["filters_size"]
        self.kernel_size = cnn_paras["kernel_size"]
        self.pool_size = cnn_paras["pool_size"]

    def _building_architecture__(self):
        #  The CNN 1-HL architecture
        self.model_rnn = Sequential()
        self.model_rnn.add(Conv1D(filters=self.filters_size, kernel_size=self.kernel_size, activation=self.activations[0],
                                  input_shape=(self.X_train.shape[1], 1)))
        self.model_rnn.add(MaxPooling1D(pool_size=self.pool_size))
        self.model_rnn.add(Flatten())
        self.model_rnn.add(Dense(self.hidden_sizes[0], activation=self.activations[1]))
        self.model_rnn.add(Dense(1))

 