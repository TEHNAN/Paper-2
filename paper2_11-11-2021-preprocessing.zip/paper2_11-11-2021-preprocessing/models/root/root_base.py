#!/usr/bin/env python
# ------------------------------------------------------------------------------------------------------%
# Created by "Thieu Nguyen" at 14:20, 25/03/2020                                                        %
#                                                                                                       %
#       Email:      nguyenthieu2102@gmail.com                                                           %
#       Homepage:   https://www.researchgate.net/profile/Thieu_Nguyen6                                  %
#       Github:     https://github.com/thieunguyen5991                                                  %
#-------------------------------------------------------------------------------------------------------%

from utils.PreprocessingUtil import TimeSeries
from utils.MeasureUtil import MeasureTimeSeries
from utils.IOUtil import _save_results_to_csv__, _save_prediction_to_csv__, _save_loss_train_to_csv__, _save_accuracy_train_to_csv__, _save_epoch_time_to_csv__
from utils.GraphUtil import _draw_predict_with_error__, _draw_score_confusion_matrix__, _draw_score_multilabel_confusion_matrix__, _output_score_classification_report
import numpy as np
"""
		This is the root of all networks
"""
class RootBase:
	
    def __init__(self, root_base_paras=None):
        self.data_original = root_base_paras["data_original"]
        self.data_original_labels = root_base_paras["data_original_labels"]
        self.train_split = root_base_paras["train_split"]
        self.data_window = root_base_paras["data_window"]
        self.sliding = len(self.data_window)
        self.scaling = root_base_paras["scaling"]
        self.feature_size = root_base_paras["feature_size"]
        self.network_type = root_base_paras["network_type"]
        self.n_runs = root_base_paras["n_runs"]
        self.path_save_result = root_base_paras["path_save_result"]
        self.log_filename = root_base_paras["log_filename"]
        self.draw = root_base_paras["draw"]
        self.log = root_base_paras["log"]
        self.model, self.solution, self.loss_train, self.filename = None, None, [], None
        self.epoch_times = []
        self.X_train, self.y_train, self.X_test, self.y_test = None, None, None, None
        self.time_total_train, self.time_epoch, self.time_predict, self.time_system = None, None, None, None
        self.time_series = None
        
    def _processing__(self):
        ## standardize the dataset using the mean and standard deviation of the training data.
        self.time_series = TimeSeries(data=self.data_original, labels=self.data_original_labels, train_split=self.train_split)
        data_new, label_new = self.data_original, self.data_original_labels #self.time_series._scaling__(self.scaling)
        #data_new=self.data_original
        #label_new=self.data_original_labels
        self.X_train, self.y_train = self.time_series._univariate_data__(data_new, label_new, self.data_window, 0, self.time_series.train_split, self.network_type)
        self.X_test, self.y_test = self.time_series._univariate_data__(data_new, label_new, self.data_window, self.time_series.train_split, None, self.network_type)
    
    def _save_train_results__(self, accuracy, precision, recall, f1, kappa, sensitivity, specificity):
        item = {'model_name': self.filename, 'total_time_train': self.time_total_train, 'time_epoch': self.time_epoch,
		        'accuracy': accuracy,
		        'precision': precision, 
                'recall': recall, 
                'f1': f1, 
                'kappa': kappa, 
                'sensitivity': sensitivity, 
                'specificity': specificity, 
                }
        _save_results_to_csv__(item, self.log_filename+'_full_train_predict', self.path_save_result)
                        
    def _save_results__(self, y_true=None, y_pred=None, y_true_scaled=None, y_pred_scaled=None, loss_train=None, accuracy_train=None, epoch_times=None, n_runs=1):
        '''
        print('y_true_scaled'+str(y_true_scaled))
        print('y_true'+str(y_true))
        print('****************************************')
        print('y_pred_scaled'+str(y_pred_scaled))
        print('y_pred'+str(y_pred))
        print('--------------------------------')
        '''
        y_true_scaled2=np.argmax(y_true_scaled, axis=1)
        y_true2=np.argmax(y_true, axis=1)
        ''' #print('y_true_scaled'+str(y_true_scaled2))
        #print('y_true'+str(y_true2))
        
        #print('****************************************')'''
        y_pred_scaled2=np.argmax(y_pred_scaled, axis=1)
        y_pred2=np.argmax(y_pred, axis=1)
        '''#print('y_pred_scaled'+str(y_pred_scaled2))
        #print('y_pred'+str(y_pred2))
        #print('--------------------------------')'''
        
        measure_scaled = MeasureTimeSeries(y_true_scaled2, y_pred_scaled2, y_true_scaled, y_pred_scaled, "raw_values", number_rounding=4)
        measure_scaled._fit__()
        measure_unscaled = MeasureTimeSeries(y_true2, y_pred2, y_true, y_pred, "raw_values", number_rounding=4)
        measure_unscaled._fit__()
        
              
        item = {'model_name': self.filename, 'total_time_train': self.time_total_train, 'time_epoch': self.time_epoch,
		        'time_predict': self.time_predict, 'time_system': self.time_system,
		        'scaled_score_roc_auc': measure_scaled.score_roc_auc, 
                'scaled_score_accuracy': measure_scaled.score_accuracy, 
                'scaled_score_precision': measure_scaled.score_precision,
		        'scaled_score_recall': measure_scaled.score_recall, 
                'scaled_score_f1': measure_scaled.score_f1, 
                'scaled_cohen_kappa': measure_scaled.cohen_kappa,
		        'scaled_specificity': measure_scaled.specificity, 
                'scaled_sensitivity': measure_scaled.sensitivity,
		        'scaled_score_matthews_corrcoef': measure_scaled.score_matthews_corrcoef, 
                'scaled_score_top_k_accuracy': measure_scaled.score_top_k_accuracy, 
                'scaled_score_jaccard_score': measure_scaled.score_jaccard_score,
		        
                'unscaled_score_roc_auc': measure_unscaled.score_roc_auc, 
                'unscaled_score_accuracy': measure_unscaled.score_accuracy, 
                'unscaled_score_precision': measure_unscaled.score_precision,
		        'unscaled_score_recall': measure_unscaled.score_recall, 
                'unscaled_score_f1': measure_unscaled.score_f1, 
                'unscaled_cohen_kappa': measure_unscaled.cohen_kappa,
		        'unscaled_specificity': measure_unscaled.specificity, 
                'unscaled_sensitivity': measure_unscaled.sensitivity,
		        'unscaled_score_matthews_corrcoef': measure_unscaled.score_matthews_corrcoef, 
                'unscaled_score_top_k_accuracy': measure_unscaled.score_top_k_accuracy, 
                'unscaled_score_jaccard_score': measure_unscaled.score_jaccard_score,
		        }
        
        if n_runs == 1:
            _save_prediction_to_csv__(y_true, y_pred, y_true_scaled, y_pred_scaled, self.filename, self.path_save_result)
            _save_loss_train_to_csv__(loss_train, self.filename, self.path_save_result + "Error-")
            _save_epoch_time_to_csv__(epoch_times, self.filename, self.path_save_result + "EpochTime-")
            _save_accuracy_train_to_csv__(accuracy_train, self.filename, self.path_save_result + "Accuracy-")
            #if self.draw:
            _draw_predict_with_error__([y_true, y_pred], [measure_unscaled.score_accuracy, measure_scaled.score_accuracy], self.filename, self.path_save_result, 'score_accuracy')
            _draw_predict_with_error__([y_true, y_pred], [measure_unscaled.score_matthews_corrcoef, measure_scaled.score_matthews_corrcoef], self.filename, self.path_save_result, 'score_matthews_corrcoef')
            _draw_predict_with_error__([y_true, y_pred], [measure_unscaled.score_precision, measure_scaled.score_precision], self.filename, self.path_save_result, 'score_precision')
            _draw_predict_with_error__([y_true, y_pred], [measure_unscaled.score_recall, measure_scaled.score_recall], self.filename, self.path_save_result, 'score_recall')
            _draw_predict_with_error__([y_true, y_pred], [measure_unscaled.score_f1, measure_scaled.score_f1], self.filename, self.path_save_result, 'score_f1')
            _draw_predict_with_error__([y_true, y_pred], [measure_unscaled.cohen_kappa, measure_scaled.cohen_kappa], self.filename, self.path_save_result, 'cohen_kappa')
            
            _draw_score_confusion_matrix__(measure_unscaled.score_confusion_matrix, self.filename, self.path_save_result)
            _draw_score_multilabel_confusion_matrix__(measure_unscaled.score_confusion_matrix, self.filename, self.path_save_result)
            _output_score_classification_report(measure_unscaled.score_classification_report)
            #if self.log:
            print('Predict DONE - Unscaled Accuracy: %f, Scaled Accuracy: %f' % (measure_unscaled.score_accuracy, measure_scaled.score_accuracy))
        _save_results_to_csv__(item, self.log_filename, self.path_save_result)
    def _forecasting__(self):
        pass
    
    def _training__(self):
        pass
    
    def _running__(self):
        pass

    '''
    item = {'model_name': self.filename, 'total_time_train': self.time_total_train, 'time_epoch': self.time_epoch,
		        'time_predict': self.time_predict, 'time_system': self.time_system,
		        'scaled_EV': measure_scaled.score_ev, 'scaled_MSLE': measure_scaled.score_msle, 'scaled_R2': measure_scaled.score_r2,
		        'scaled_MAE': measure_scaled.score_mae, 'scaled_MSE': measure_scaled.score_mse, 'scaled_RMSE': measure_scaled.score_rmse,
		        'scaled_MAPE': measure_scaled.score_mape, 'scaled_SMAPE': measure_scaled.score_smape,
		        'unscaled_EV': measure_unscaled.score_ev, 'unscaled_MSLE': measure_unscaled.score_msle, 'unscaled_R2': measure_unscaled.score_r2,
		        'unscaled_MAE': measure_unscaled.score_mae, 'unscaled_MSE': measure_unscaled.score_mse, 'unscaled_RMSE': measure_unscaled.score_rmse,
		        'unscaled_MAPE': measure_unscaled.score_mape, 'unscaled_SMAPE': measure_unscaled.score_smape
    '''