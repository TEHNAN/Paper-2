#!/usr/bin/env python
# ------------------------------------------------------------------------------------------------------%
# Created by "Thieu Nguyen" at 14:37, 31/01/2020                                                        %
#                                                                                                       %
#       Email:      nguyenthieu2102@gmail.com                                                           %
#       Homepage:   https://www.researchgate.net/profile/Thieu_Nguyen6                                  %
#       Github:     https://github.com/thieunguyen5991                                                  %
#-------------------------------------------------------------------------------------------------------%

import tensorflow as tf
import numpy as np
import random
#from utils.FunctionUtil import *

def _unslice_actual_solutions__(pop):
        unsliced_pop=[]
        for p in pop:
            i=p[0]
            unsliced_pop.append(i)
        return unsliced_pop
"""
Constants and values describing rates and variables
"""
'''
Settings from the paper
--------------------------------------------------------------------------------------------
 Notation       Definition                                                     Range of Value
--------------------------------------------------------------------------------------------
    π     Recruitment rate of susceptible human individuals                          Variable
    ŋ    Decay rate of Ebola virus in the environment                               (0, )
    α    Rate of hospitalization of infected individuals                               (0, 1)
        Disease-induced death rate of human individuals                               [0.4, 0.9]
    β1    Contact rate of infectious human individuals                               Variable
    β2    Contact rate of pathogen individuals/environment                           Variable
    β3    Contact rate of deceased human individuals                                   Variable
    β4    Contact rate of recovered human individuals                                   Variable
        Recovery rate of human individuals                                           (0, 1)
        Natural death rate of human individuals                                       (0, 1)
        Rate of  burial of deceased human individuals                               (0, 1)
        Rate of vaccination of individuals                                           (0, 1)
        Rate of response to hospital treatment                                       (0, 1)
        Rate response to vaccination                                               (0, 1)
'''
π=0.1 #Recruitment rate of susceptible human individuals
ŋ=np.random.rand() #Decay rate of Ebola virus in the environment
α=np.random.rand() #Rate of hospitalization of infected individuals
dis=random.uniform(0.4, 0.9)#Disease-induced death rate of human individuals
β_1=0.1#Contact rate of infectious human individuals
β_2=0.1#Contact rate of pathogen individuals/environment
β_3=0.1#Contact rate of deceased human individuals
β_4=0.1#Contact rate of recovered human individuals
rr=np.random.rand() #Recovery rate of human individuals
dr=np.random.rand() #Natural death rate of human individuals
br=np.random.rand() #Rate of  burial of deceased human individuals
vr=np.random.rand() #Rate of vaccination of individuals
hr=np.random.rand() #Rate of response to hospital treatment
vrr=np.random.rand() #Rate response to vaccination
qrr=np.random.rand()	#Rate of quarantine of infected individuals

save_results_dir='./history/Lung_cancer_Result/'

modelrates = {
    "recruitment_rate": π,
    "decay_rate": ŋ,
    "hospitalization_rate": α,
    "disease_induced_death_rate": dis,
    "contact_rate_infectious": β_1,
    "contact_rate_pathogen": β_2,
    "contact_rate_deceased": β_3,
    "contact_rate_recovered": β_4,
    "recovery_rate": rr,
    "natural_death_rate": dr,
    "burial_rate": br,
    "vacination_rate": vr,
    "hospital_treatment_rate": hr,
    "vaccination_response_rate": vrr,
    "quarantine_rate": qrr
}

SPF_RUN_TIMES = 1
SPF_2D_NETWORK = "2D"
SPF_3D_NETWORK = "3D"
SPF_SCALING = "" #minmax, std
SPF_FEATURE_SIZE = 114
SPF_TRAIN_SPLIT = 0.75
SPF_LOG_FILENAME = "result"
SPF_PATH_SAVE_BASE = "./history/results_final_2/Lung_cancer_Result/"
SPF_DRAW = True
SPF_LOG = 1  # 0: nothing, 1 : full detail, 2: short version
SPF_VERBOSE = True #True, False

SPF_LOAD_DATA_FROM = " "

SPF_DATA_FILENAME = ["Lung_cancer_Result"]  #f_occupancy_t4013", "f_speed_7578", "f_TravelTime_451
SPF_DATA_COLS = [[1], [1], [1]]
SPF_DATA_WINDOWS = [(1,2,3,4,5,6,7,8,9,10,11,12), (1,2,3,4,5), (1,2,3,4)]  # Using ACF to determine which one will used


###### Setting for paper running on server ==============================
epochs = [5]
activations = [("elu", "elu")]

hidden_sizes1 = [(7, True), ]  # (num_node, checker), default checker is True
learning_rates = [0.001]
optimizers = [tf.keras.optimizers.Adam(lr=0.001, beta_1=0.9, beta_2=0.999, epsilon=1e-8)]  #  tf.keras.optimizers.SGD(lr=0.01, decay=1e-6, momentum=1, nesterov=True)  Adam(lr=0.001, beta_1=0.9, beta_2=0.999, epsilon=1e-8)
losses = ["categorical_crossentropy"]  #categorical_crossentropy, mse
batch_sizes = [32]
dropouts = [(0.2,)]

hidden_sizes2 = [([7, ], True), ]
pop_sizes = [50]
domain_ranges = [(-1, 1)]

## For ELM network
elm_activation = ['elu']

## For CNN networks
filters_sizes = [8, ]
kernel_sizes = [3, ]
pool_sizes = [2, ]


###================= Settings models for drafts ==============================#####

####: RNN-1HL
rnn1hl_final = {
	"hidden_sizes": hidden_sizes1,
	"activations": activations,
	"learning_rate": learning_rates,
	"epoch": epochs,
	"batch_size": batch_sizes,
	"optimizer": optimizers,
	## Optimizer like keras: sgd = SGD, adam = Adam,  adagrad = Adagrad, adadelta = Adadelta, rmsprop = RMSprop, adamax = Adamax, nadam = Nadam
	"loss": ['mse'],
	"dropouts": dropouts
}
 
Cnn6HL_final ={
    "hidden_sizes": hidden_sizes1,
	"activations": activations,
	"learning_rate": learning_rates,
	"epoch": epochs,
	"batch_size": batch_sizes,
	"optimizer": optimizers,
	"loss": losses,
	"dropouts": dropouts,

	"filters_size": filters_sizes,
	"kernel_size": kernel_sizes,
	"pool_size": pool_sizes
}
    
    
   


####: CNN-1
cnn1_final = {
	"hidden_sizes": hidden_sizes1,
	"activations": activations,
	"learning_rate": learning_rates,
	"epoch": epochs,
	"batch_size": batch_sizes,
	"optimizer": optimizers,
	"loss": losses,
	"dropouts": dropouts,

	"filters_size": filters_sizes,
	"kernel_size": kernel_sizes,
	"pool_size": pool_sizes
}

###================= Settings models for paper hybrid-CNN ============================####

#### : GA-CNN
ga_cnn_final = {
	"hidden_sizes": hidden_sizes2,
	"activations": activations,
	"dropouts": dropouts,

	"filters_size": filters_sizes,
	"kernel_size": kernel_sizes,
	"pool_size": pool_sizes,

	"epoch": epochs,
	"pop_size": pop_sizes,
	"pc": [0.95],  # 0.85 -> 0.97
	"pm": [0.025],  # 0.005 -> 0.10
	"domain_range": domain_ranges
}

#### : WOA-CNN
woa_cnn_final = {
	"hidden_sizes": hidden_sizes2,
	"activations": activations,
	"dropouts": dropouts,

	"filters_size": filters_sizes,
	"kernel_size": kernel_sizes,
	"pool_size": pool_sizes,

	"epoch": epochs,
	"pop_size": pop_sizes,
	"domain_range": domain_ranges
}

#### : MVO-CNN
mvo_cnn_final = {
	"hidden_sizes": hidden_sizes2,
	"activations": activations,
	"dropouts": dropouts,

	"filters_size": filters_sizes,
	"kernel_size": kernel_sizes,
	"pool_size": pool_sizes,

	"epoch": epochs,
	"pop_size": pop_sizes,
	"wep_minmax": [(1.0, 0.2), ],
	"domain_range": domain_ranges
}

#### : SBO-CNN
sbo_cnn_final = {
	"hidden_sizes": hidden_sizes2,
	"activations": activations,
	"dropouts": dropouts,

	"filters_size": filters_sizes,
	"kernel_size": kernel_sizes,
	"pool_size": pool_sizes,

	"epoch": epochs,
	"pop_size": pop_sizes,
	"alpha": [0.94],
	"pm": [0.05],
	"z": [0.02],
	"domain_range": domain_ranges
}

#### : LCBO-CNN
lcbo_cnn_final = {
	"hidden_sizes": hidden_sizes2,
	"activations": activations,
	"dropouts": dropouts,

	"filters_size": filters_sizes,
	"kernel_size": kernel_sizes,
	"pool_size": pool_sizes,

	"epoch": epochs,
	"pop_size": pop_sizes,
	"domain_range": domain_ranges
}

#### : eosa-CNN
eosa_cnn_final = {
	"hidden_sizes": hidden_sizes2,
	"activations": activations,
	"dropouts": dropouts,

	"filters_size": filters_sizes,
	"kernel_size": kernel_sizes,
	"model_rates": modelrates,

	"epoch": epochs,
	"pop_size": pop_sizes,
    "pop_size": pop_sizes,
	"domain_range": domain_ranges,
    "pool_size": pool_sizes
	 
     
}

#### : SSA-CNN
ssa_cnn_final = {
	"hidden_sizes": hidden_sizes2,
	"activations": activations,
	"dropouts": dropouts,

	"filters_size": filters_sizes,
	"kernel_size": kernel_sizes,
	"pool_size": pool_sizes,

	"epoch": epochs,
	"pop_size": pop_sizes,
	"domain_range": domain_ranges,
    
    "r_a":[1],
    "p_c":[0.7],
    "p_m":[0.1],
}

#### : SRSR-CNN
srsr_cnn_final = {
	"hidden_sizes": hidden_sizes2,
	"activations": activations,
	"dropouts": dropouts,

	"filters_size": filters_sizes,
	"kernel_size": kernel_sizes,
	"pool_size": pool_sizes,

	"epoch": epochs,
	"pop_size": pop_sizes,
	"domain_range": domain_ranges
}


#### : EO-CNN
eo_cnn_final = {
	"hidden_sizes": hidden_sizes2,
	"activations": activations,
	"dropouts": dropouts,

	"filters_size": filters_sizes,
	"kernel_size": kernel_sizes,
	"pool_size": pool_sizes,

	"epoch": epochs,
	"pop_size": pop_sizes,
	"domain_range": domain_ranges
}

#### : AEO-CNN
aeo_cnn_final = {
	"hidden_sizes": hidden_sizes2,
	"activations": activations,
	"dropouts": dropouts,

	"filters_size": filters_sizes,
	"kernel_size": kernel_sizes,
	"pool_size": pool_sizes,

	"epoch": epochs,
	"pop_size": pop_sizes,
	"domain_range": domain_ranges
}


'''
Result in Floyd
GA= 41 (perfect), 42 (not perfect)
MVO=43 (perfect)
SBO=58 (perfect) 54 (near perfect) 44 (not perfect)
WOA=45 (perfect)
LCBO=56 (perfect), 43 (not perfect)
CNN= 62 (perfect), 57, 53, 
'''